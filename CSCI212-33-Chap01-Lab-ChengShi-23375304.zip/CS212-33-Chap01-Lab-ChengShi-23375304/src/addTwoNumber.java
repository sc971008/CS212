import java.util.Scanner;

public class addTwoNumber {
	public static void main(String[]args) {
		int num1=0;//The first Number User Input
		int num2=0;//The second Number User Input
		int sum;	//Storage the Ans to sum
		
		
		Scanner input= new Scanner(System.in);
		//scan the input from User.
		System.out.print("Enter the First number you want to get the sum: ");
		//Output a UI to ask User for input.
		num1= input.nextInt();
		//get the data from scanner pass it to num1.
		
		System.out.print("Enter the next Number: ");
		num2= input.nextInt();
		
		sum=num1+num2;
		
		
		System.out.println(sum);
		
		
		
		
		
		
	}
}
