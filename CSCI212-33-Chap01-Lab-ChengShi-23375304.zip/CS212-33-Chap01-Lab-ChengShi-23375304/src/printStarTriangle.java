import java.util.Scanner;

public class printStarTriangle {
	public static void main(String[]args) {
	
	Scanner input = new Scanner(System.in);
	System.out.print("Enter the height of triangle: ");
	int height = input.nextInt();
	
	
	for(int r=0;r<=height;r++){//loop move down to the row after finished col.
		
		for(int c=0;c<=r;c++) {//loop move to the nextCol if finished.
			System.out.print("x ");
		}
		System.out.println();//print x ,if finished next line
		
	}
	
	
		}
}
