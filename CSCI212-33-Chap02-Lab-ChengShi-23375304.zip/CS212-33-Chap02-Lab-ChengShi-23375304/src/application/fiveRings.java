package application;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.shape.ArcType;
import javafx.stage.Stage;

public class fiveRings extends Application{
	 
	public static void main(String[]args) {
		launch(args);
	}
	
	@Override
	public void start(Stage primaryStage) {
		Group root=new Group();
		Scene scene=new Scene(root);
		Canvas canvas=new Canvas(400,300);
		GraphicsContext pen= canvas.getGraphicsContext2D();
		
		
		pen.setLineWidth(10);
		
		pen.setStroke(Color.BLUE);//1
		pen.strokeArc(10,10,100,100,135,180,ArcType.OPEN);//Blue ring
		
		pen.setStroke(Color.YELLOW);//2
		pen.strokeArc(70,70,100,100,135,225,ArcType.OPEN);
		
		pen.setStroke(Color.YELLOW);//3
		pen.strokeArc(70,70,100,100,90,45,ArcType.OPEN);
	
		pen.setStroke(Color.BLUE);//4
		pen.strokeArc(10,10,100,100,-45,180,ArcType.OPEN);
		
		pen.setStroke(Color.BLACK);//1
		pen.strokeArc(130,10,100,100,0,180+45,ArcType.OPEN);
		
		pen.setStroke(Color.YELLOW);//2
		pen.strokeArc(70,70,100,100,45,45,ArcType.OPEN);
		
		pen.setStroke(Color.YELLOW);//3
		pen.strokeArc(70,70,100,100,0,45,ArcType.OPEN);
		
		pen.setStroke(Color.BLACK);//4
		pen.strokeArc(130,10,100,100,225,45,ArcType.OPEN);
		
		pen.setStroke(Color.BLACK);//1
		pen.strokeArc(130,10,100,100,270,45,ArcType.OPEN);
		
		pen.setStroke(Color.GREEN);//2
		pen.strokeArc(70+120,70,100,100,90,270,ArcType.OPEN);
		
		pen.setStroke(Color.BLACK);//3
		pen.strokeArc(130,10,100,100,-45,45,ArcType.OPEN);
		
		pen.setStroke(Color.RED);//1
		pen.strokeArc(130+120,10,100,100,-90,315,ArcType.OPEN);
		
		pen.setStroke(Color.GREEN);//2
		pen.strokeArc(70+120,70,100,100,0,90,ArcType.OPEN);
		
		pen.setStroke(Color.RED);//3
		pen.strokeArc(130+120,10,100,100,225,45,ArcType.OPEN);
		
		
		
		
		
		
		root.getChildren().add(canvas);
		primaryStage.setTitle("HappyFace");
		primaryStage.setScene(scene);
		primaryStage.show();
	}

}