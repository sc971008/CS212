package application;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.shape.ArcType;
import javafx.stage.Stage;

public class sadFace extends Application{
	 
	public static void main(String[]args) {
		launch(args);
	}
	
	@Override
	public void start(Stage primaryStage) {
		Group root=new Group();
		Scene scene=new Scene(root);
		Canvas canvas=new Canvas(400,300);
		GraphicsContext gc= canvas.getGraphicsContext2D();
		
		gc.setLineWidth(10);
		gc.strokeOval(100,50,200,200);//Shape of Face(empty)
		gc.fillOval(155, 100, 10, 20);//out put a Oval (Filled left eye)
		gc.fillOval(230, 100, 10, 20);//right eye
		gc.strokeArc(150,160,100,50,360,180, ArcType.OPEN);
		
		root.getChildren().add(canvas);
		primaryStage.setTitle("HappyFace");
		primaryStage.setScene(scene);
		primaryStage.show();
	}

}



