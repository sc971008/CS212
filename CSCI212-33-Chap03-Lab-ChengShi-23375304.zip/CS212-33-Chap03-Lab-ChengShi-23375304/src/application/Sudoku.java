package application;
	
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.stage.Stage;
/**
 * @author Cheng Shi
 * use for loop to draw vertical lines 10 times because it's (9*9)
 * keep adding the (codinate x) vaule for starting point and end point 
 * make the 3rd and 6th line thick
 * same for the horizontal lines
 */
public class Sudoku extends Application {
	
	
	@Override
	public void start(Stage primaryStage) {
		Group root=new Group();
		Scene scene=new Scene(root);
		Canvas canvas=new Canvas(270,270);
		GraphicsContext pen= canvas.getGraphicsContext2D();
		
		
		pen.setLineWidth(0.5);
		
		int startx=0;//draw vertical lines
		int endx=0;
		for(int i=0;i<=10;i++) {//draw the line 10 time
			if(i%3==0)pen.setLineWidth(2);//if it's boarder make it thick
			pen.strokeLine(startx, 0, endx, 270);
			startx=startx+30;//keep going right
			endx=endx+30;
			pen.setLineWidth(0.5);//reset the width of line
		}
		
		
		int starty=0;//draw horizontal line
		int endy=0;
		for(int i=0;i<=10;i++){
			if(i%3==0)pen.setLineWidth(2);
			pen.strokeLine(0,starty,270,endy);
			starty+=30;
			endy+=30;
			pen.setLineWidth(0.5);
		}
		
		
		
		
		root.getChildren().add(canvas);
		primaryStage.setTitle("Sudoku board");
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
