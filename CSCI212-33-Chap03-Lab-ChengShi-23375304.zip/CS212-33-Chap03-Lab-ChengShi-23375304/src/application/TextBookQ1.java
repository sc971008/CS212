package application;
import java.util.Scanner;
/**
 * 
 * @author Cheng Shi
 * Ask User input the Faharenhit degree
 * convert the number to Celsiuss by use the C=(F-32)/9
 * 
 * output the Fahrenheit with out decimal by using "%.0f"
 * output the Celsius with only one decimal by using"%.1f"
 * 
 *
 */

public class TextBookQ1 {
	public static void main(String[]args) {
		double tempC=0;
		double tempF=0;
		
		Scanner input= new Scanner(System.in);
		//set the input as scanner
		System.out.print("Enter a temperature in degress Faharenhit: ");
		//ask user to input 
		tempF= input.nextDouble();
		//scanner the input to tempF
		
		tempC=5*(tempF-32)/9;
		//calculate the result 
		
		System.out.printf("%.0f",tempF);
		System.out.print(" drgress Fahrenheit is ");
		System.out.printf("%.1f",tempC);
		System.out.print(" degress in Celsius.");
	}
}
