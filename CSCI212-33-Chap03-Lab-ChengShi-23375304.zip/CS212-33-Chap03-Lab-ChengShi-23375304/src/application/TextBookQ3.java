package application;
import java.util.Scanner;
/**
 * 
 * @author Cheng Shi
 * 1.get the sentence from user
 * 2.get the position index where the first space is
 * 3.use substring(0,index)to get the first word
 * 4.use substring(index+1��to get the rest of sentence
 * 5.use substring to get the first char of the sentence after the first then make it Cap
 * 
 * 6.then add the first char to the rest
 * 7.output the result of rest of sentence and first word toghter.
 *
 */

public class TextBookQ3 {
	public static void main(String[] args) {
		Scanner input= new Scanner(System.in);
		
		String s1="",s2="";
		String firstWord="";
		String restWord="";
		
		int endIndex=0;//the index postion of the the space after the first word
		
		System.out.println("Enter a line of text. No punctuation please.");
		s1= input.nextLine();
		
		endIndex= s1.indexOf(" ");//get the postion of the space
		firstWord=s1.substring(0,endIndex);//get the first word by scan(0,space postion)
		restWord=s1.substring(endIndex+1);//get the rest of string after the space
		restWord=restWord.substring(0,1).toUpperCase()+restWord.substring(1);
		//make the First Char Upper case then add the rest of the string
		
		System.out.print("I have rephrased that line to read: \n");
		System.out.print(restWord+" "+firstWord);
	}
}
