package application;
import java.util.Scanner;
/**
 * 
 * @author Cheng Shi
 * Ask user to input the info
 * store the info into strings
 * output the line with the info of User by fill the strings by it's input
 *
 */
public class TextBookQ4 {
	public static void main(String[] args) {	
		Scanner input= new Scanner(System.in);
		//set the scanner
		
		String name,color,animal,food="";
		//initial all the string
		
		
		System.out.print("Please enter your favorite color: ");
		color=input.next();
		System.out.print("Please enter your favorite food: ");
		food=input.next();
		System.out.print("Please enter your favorite animal: ");
		animal=input.next();
		System.out.print("Please enter the first name of a friend or relative: ");
		name=input.next();
		//ask User to input all the info.
		
		
		System.out.print("I had a dream that "+name+" ate a "+color+" "+animal+"\n");
		System.out.print("and said it tasted like "+food+"!");
		//put the info into the sentence then out put to the User.
		
	}
	}
