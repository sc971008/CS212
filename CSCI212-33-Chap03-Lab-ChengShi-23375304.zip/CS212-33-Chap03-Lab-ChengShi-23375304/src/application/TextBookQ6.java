package application;
import java.util.Scanner;
/**
 * 
 * @author Cheng Shi
 * use substring to get each digit of binary number separately
 * convert the string to int type so we can do the math;
 * convert the binary to decimal number by the 
 * function "decimal=2^3*b0 + 2^2*b1 + 2^1*b2 + 2^0*b3"
 * output the value
 *
 */
public class TextBookQ6 {
	public static void main(String[]args) {
		Scanner input= new Scanner(System.in);
		
		
		System.out.print("Enter a 4 bit binary number: ");
		String binary= input.nextLine();
		if(binary.length()>4) {
			System.out.print("Wrong number!");
			return;
		}
		
		
		String sb0=binary.substring(0,1);//get all the binary# string separately
		String sb1=binary.substring(1,2);
		String sb2=binary.substring(2,3);
		String sb3=binary.substring(3,4);
		
		
		int b0= Integer.parseInt(sb0);//convert string to int;
		int b1= Integer.parseInt(sb1);
		int b2= Integer.parseInt(sb2);
		int b3= Integer.parseInt(sb3);
		
		
		
		int decimal=8*b0+4*b1+2*b2+b3;//calculte the value of decimal
		System.out.print("After Conver this number to decimal:"+decimal);
		
	}
}
