package application;
import java.util.Scanner;
/**
 * 
 * @author Cheng Shi
 * get the input from user.
 * use "replaceFirst" function to replace the first word in string to the word we want.
 * output the sentence string with the word replaced
 *
 */
public class TextbookQ2 {
	public static void main(String[]args) {
		String badWord;
		String goodWord;
		
		Scanner input= new Scanner(System.in);
		//set the scanner
		System.out.println("Enter a line of text: ");
		//ask user to input the bad words
		badWord=input.nextLine();
		//get the input to string 
		
		goodWord=badWord.replaceFirst("hate","love");
		//replace the first word in string
		System.out.println(goodWord);
	}
} 
