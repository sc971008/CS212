package application;
import java.util.Scanner;
/**
 * 
 * @author Cheng Shi
 * get the price of the merchant
 * calculate the change by(change=100-price)
 * get the maximum amount of quater first by divide the change by 25
 * use %25 to get the remainder which is the how much left after can we use after took out the quarters.
 * same for the dime and nickle
 * 
 * output result
 * check if there is only one single coin
 * if does don't out put ��s��
 * 
 */

public class TextbookQ5 {
	public static void main(String[] args) {
		Scanner input =new Scanner(System.in);
		
		
		System.out.print("Enter price of item: ");
		int price=input.nextInt();
		if(price>100||price%5!=0){// bad input check;
			System.out.print("Wrong price!");
			return;
		}
		
		
		int change=100-price;//get the change amount
		
		int q=change/25;//amount of [quater]
		change=change%25;//get the rest of number
		
		int d=change/10;//amount of [dime]
		change=change%10;//get the rest 
		
		int n=change/5;//amount of [nickel]
		
		
		
		
		System.out.print("You bought an item for "+price+" cents and gave me a dollar,\n");
		System.out.print("so your charge is:\n");

		
		
		
		
		if(q==1) {//if it's only one qauter no ��s�� behind.
			System.out.print("1 quarter\n");
		}
		else
			System.out.print(q+" quarters\n");
		
		
		if(d==1) {
			System.out.print("1 dime, and\n");
			}
			else
			System.out.print(d+" dimes, and\n");
		
		if(n==1) {
			System.out.print("1 nickel.");
			}
			else
			System.out.print(n+" nickels.");
		
		
		
	}
}
