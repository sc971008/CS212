package chap08.abstract_class_ex;

public class Circle extends Shape {
	//<Variables>
	protected double radius=1.0;
	
	//<Constructor>
	public Circle() {
	}
	public Circle(double radius) {
		this.radius=radius;
	}
	public Circle(double radius,String color) {
		super(color);
		this.radius=radius;
	}
	//<getter/setter>
	public double getRadius() {
		return radius;
	}
	public void setRadius(double radius) {
		this.radius = radius;
	}
	
	//<Method implements to Shape>
	@Override
	public double getArea() {
		return Math.PI*radius*radius;
	}
	public double getPerimeter() {
		return 2*Math.PI*radius;
	}
	
	//<Override New toString>
	public String toString() {
		return "Circle["+super.toString()+",radius="+radius+"]";
	}
}
