package chap08.abstract_class_ex;

public abstract class Shape {
	//<Varibales>
	protected String color="red";
	protected boolean filled;
	
	//<Constructor>
	public Shape() {
	}
	public Shape(String color) {
		this.color=color;
	}
	//* I leave this the output test you provided does not have "filled" *
	public Shape(String color,boolean filled) {
	}	
	
	//<getter/setter>
	public String getColor() {
		return this.color;
	}
	
	public void setColor(String color) {
		this.color=color;
	}
	
	//<abstract Method>
	public abstract double getArea();
	public abstract double getPerimeter();
	public abstract double getRadius();
	//<toString>
	public String toString() {
		return "Shape[color="+color+"]" ;
	}
	
	
	
}	
