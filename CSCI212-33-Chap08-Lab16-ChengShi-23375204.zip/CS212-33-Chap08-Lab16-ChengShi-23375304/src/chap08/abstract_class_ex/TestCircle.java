package chap08.abstract_class_ex;

public class TestCircle 
{
	public static void main(String[] args) 
	{
		Shape s1 = new Circle(5.5, "blue");    // Upcast Circle to Shape
		System.out.println(s1);                // which version? Circle
		System.out.println(s1.getArea());      // which version? Circle
		System.out.println(s1.getPerimeter()); // which version? Circle
		System.out.println(s1.getColor());
		//===========================================================
		// try to uncomment the following statement
		// if you see compilation error.  provide your explanation
		
		// *Ans:Upcast Circle to Shape,so s1 can only use either its (abstract method) 
		//      that's implemented by subclass or it's own method
		//		getRadius() won't work because it 
		//	*Solution: declare getRadius() in the Shape Class as abstract method
		//
		//===========================================================
		System.out.println(s1.getRadius());   
		   
		System.out.println();
		Circle c1 = (Circle)s1;                // Downcast back to Circle
		System.out.println(c1);
		System.out.println(c1.getArea());
		System.out.println(c1.getPerimeter());
		System.out.println(c1.getColor());
		System.out.println(c1.getRadius());
	}
}

