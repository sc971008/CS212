package chap08.inheritance_ex;

public class Cylinder extends Circle {
	//<variables>
	private double height=1.0;
	
	//<Constructor>
	public Cylinder() {
		super();
	}
	public Cylinder(double radius) {
		super(radius);
	}
	public Cylinder(double radius,double height) {
		super(radius);
		this.height=height;
	}
	public Cylinder(double radius,double height,String color) {
		super(radius,color);
		this.height=height;
	}
	
	//<getter/setter>
	public double getHeight() {
		return this.height;
	}
	public void setHeight(double height) {
		this.height=height;
	}
	
	//<Method>
	public double getVolume() {
		return getArea()*height;
	}
	
	@Override
	public String toString() {
		return "Cylinder: subclass of "+super.toString()+" height is :"+getHeight();
	}
	
	
}
