package chap08.inheritance_ex;

public class TestOverrideToString {
	
	public static void main(String[] args) 
	{
		Circle[] circles = new Circle[6];
	
	      circles[0] = new Circle();
	      circles[1] = new Circle(2.0);
	      circles[2] = new Cylinder();
	      circles[3] = new Cylinder(3.0);
	      circles[4] = new Cylinder(4.0, 6.0);
	      circles[5] = new Cylinder(4.0, 6.0, "green");
	
	      for (Circle circle: circles)
	      {
	         System.out.println( circle.toString());
	      }		
	}
	

}
