package chap08.interface_ex;

public class Circle implements Resizable,GeometricObject{
	//<Variables>
	protected double radius=1.0;
	//<Constructor>
	public Circle(double radius) {
		this.radius=radius;
	}
	
	//<toString>
	@Override
	public String toString() {
		return "Circle[radius="+radius+"]";
	}
	//<Resizable Method>
	public void resize(int percent) {
		this.radius=radius*percent/100;
	}
	//<GeometricObject Method>
	public double getPerimeter() {
		return 2*Math.PI*radius;
	}
	public double getArea() {
		return Math.PI*Math.pow(radius, 2);
	}
}
