package chap08.interface_ex;

public interface GeometricObject {
	double getPerimeter();
	double getArea();
}
