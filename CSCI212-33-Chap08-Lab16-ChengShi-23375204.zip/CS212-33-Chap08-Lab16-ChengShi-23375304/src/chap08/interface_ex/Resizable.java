package chap08.interface_ex;

public interface Resizable {
	void resize(int percent);
}
