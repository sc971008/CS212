package chap08.interface_ex;

public class TestCircle 
{
	public static void main(String[] args) 
	{
		Circle c1 = new Circle(2.0);
		System.out.println(c1);
		
		Resizable r1 = c1;
		System.out.println ("resize 200 percent");
		r1.resize(200);
		System.out.println(r1);
		
		System.out.println ("resize 25 percent");
		r1.resize(25);
		System.out.println(r1);
		
		System.out.println();
		GeometricObject g1 = c1;
		System.out.println(g1);
		System.out.println("area=" + g1.getArea());
		System.out.println("perimeter=" + g1.getPerimeter());				
	}
}
