package chap08.checked_exception;

import java.io.EOFException;
import java.io.FileNotFoundException;

public class CheckedExceptionsTestAp2 {

	public void methodA() 	{
		System.out.println("Enter methodA()");
		try {
		methodB();
		}
		catch(FileNotFoundException e){
			//System.out.println(e.getMessage());
		}
		catch(EOFException e) {
			//System.out.println(e.getMessage());
		}
		System.out.println("Exit methodA()");
	}

	public void methodB() throws FileNotFoundException,
								 EOFException {
		System.out.println("Enter methodB()");		
		methodC();
		System.out.println("Exit methodB()");
	}
	
	public void methodC() throws FileNotFoundException,  
	                             EOFException  {
		System.out.println("Enter methodC()");
		long currentTime = System.currentTimeMillis();
		if ( currentTime % 2 == 0 )
		   throw new FileNotFoundException("file does not exists");
		else
		   throw new EOFException ("Reached the end of file");
	}
		
	public static void main (String[] args ) {
		CheckedExceptionsTestAp2 test = new CheckedExceptionsTestAp2();
		test.methodA();
	}
}	
