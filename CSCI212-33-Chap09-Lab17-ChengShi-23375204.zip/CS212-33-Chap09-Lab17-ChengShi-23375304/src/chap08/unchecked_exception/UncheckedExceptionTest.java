package chap08.unchecked_exception;

public class UncheckedExceptionTest {	
	// variable member a is declared and not created
	// it is initialized with default value null
	int[] a; 
	
	public  void methodA() 	{
		System.out.println("Enter methodA()");
		methodB();
		System.out.println("Exit methodA()");
	}

	public  void methodB() 	{
		System.out.println("Enter methodB()");		
		methodC();
		System.out.println("Exit methodB()");
	}

//	public  void methodC() 	{
//		System.out.println("Enter methodC()");        
//		System.out.println("Exit methodC()");
//	}
	public  void methodC() 	{
		try {
			System.out.println("Enter methodC()");
		    for ( int i = 0; i< 2; i++) {
		           // note int[] a is null 
		           //  following statement throw NullPointerException
			     a[i] = i;           		
			}    
		}
		catch(Exception e) {
			//System.out.println(e.getMessage());
		}
		
		System.out.println("Exit methodC()");
	}  
	
	public static void main(String[] args)	{		
		UncheckedExceptionTest ucet = new UncheckedExceptionTest();		
		ucet.methodA();
	}	
}

