package chap05.lab10;
/**
 * Test all the method in Class [Time]
 * @author Cheng Shi
 * CS212-33-Chap05-Lab10
 *
 */
public class TestTime {
	public static void main(String args[]) {
	
	//Default constructor test
	
		//test default time output
	System.out.println("-------default time output Test");
	Time t1=new Time();
	System.out.println(t1);
	System.out.println("Hour:"+t1.getHour());
	System.out.println("Minute:"+t1.getMinute());
	System.out.println("Second:"+t1.getSecond());
	
		//test hour,minute,second set 
	System.out.println("-------setTime Test1 ");
	t1.setHour(11);
	t1.setMinute(01);
	t1.setSecond(13);
	System.out.println(t1);
	System.out.println("Hour:"+t1.getHour());
	System.out.println("Minute:"+t1.getMinute());
	System.out.println("Second:"+t1.getSecond());
	
	
		//test time set
	System.out.println("-------setTime test2 ");
	t1.setTime(12,13,59);
	System.out.println(t1);
	System.out.println("Hour:"+t1.getHour());
	System.out.println("Minute:"+t1.getMinute());
	System.out.println("Second:"+t1.getSecond());
	
		//nextSecond Test
	System.out.println("-------nextSecond Test ");
	t1.setTime(23,59,59);
	System.out.println(t1.nextSecond());
	t1.setTime(00,00,59);
	System.out.println(t1.nextSecond());
	t1.setTime(00,59,00);
	System.out.println(t1.nextSecond());
	
	
		//previousSecond Test
	System.out.println("-------previousSecond Test ");
	t1.setTime(00,00,00);
	System.out.println(t1.previousSecond());
	t1.setTime(12,12,00);
	System.out.println(t1.previousSecond());
	t1.setTime(12,00,00);
	System.out.println(t1.previousSecond());
	

	
	
	
	}
	


}
