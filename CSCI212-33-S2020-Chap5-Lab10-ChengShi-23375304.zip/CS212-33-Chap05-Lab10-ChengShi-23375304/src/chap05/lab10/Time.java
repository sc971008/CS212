package chap05.lab10;
/**
 * ******************<Time>**************
 * [Variables>]
 * -hour
 * -minute
 * -second
 * 
 * [Constructor]:
 * -Time()
 * -Time(hour:int,minute:int,second:int)
 * 
 * [publicMethod]:
 * -getHour():int
 * -getMinute():int
 * -getSecond():int
 * -setHour():void
 * -setMinute():void
 * -setSecond():void
 * -setTime():void
 * -toString():String
 * -nextSecond():Time
 * -previous():Time
 * 
 * @author [Cheng Shi]
 * CS212-33-Chap05-Lab10
 *
 */
public class Time {
	//--------------<Variables>----------
	private int hour;
	private int minute;
	private int second;
	
	//-------------<Constructor>----------
	
	//1st Constructor(Default)
	public Time() {									
		hour=0;
		minute=0;
		second=0;
	}
	
	//2nd Constructor
	public Time(int hr,int min,int sec) {			
		if(hr>=0&&hr<=23)this.hour=hr;
		else throw new IllegalArgumentException("Hour is out of range");
	
		if(min>=0&&min<=59)this.minute=min;
		else throw new IllegalArgumentException("Minute is out of range");
		
		if(sec>=0&&sec<=59)this.second=sec;
		else throw new IllegalArgumentException("Second is out of range");
	}
	
	//-----<PublicMethod>------

	//getter
	public int getHour() {
		return hour;
	}
	public int getMinute() {
		return minute;
	}
	public int getSecond() {
		return second;
	}
	
	//setter
	public void setHour(int num) {
		this.hour=num;
	}
	public void setMinute(int num) {
		this.minute=num;
	}
	public void setSecond(int num) {
		this.second=num;
	}
	public void setTime(int hr,int min,int sec ) {
		this.hour=hr;
		this.minute=min;
		this.second=sec;
	}
	
	//toString
	public String toString() {
	String hr=String.format("%02d", hour);
	String min=String.format("%02d", minute);
	String sec=String.format("%02d", second);
		return "Time["+hr+":"+min+":"+sec+"]";
	}
	
	//nextSecond
	public Time nextSecond() {
		int hr=this.getHour();
		int min=this.getMinute();
		int sec=this.getSecond();
		
		sec=sec+1;
		if(sec==60) {
			sec=00;
			min++;
			if(min==60) {
				min=00;
				hr++;
				if(hr==24) {
					hr=00;
				}
			}
		}	
		Time t=new Time(hr,min,sec);
		return t;		
		}
		
	//previousSecond
	public Time previousSecond() {
		int hr=this.getHour();
		int min=this.getMinute();
		int sec=this.getSecond();
		
		sec--;
		if (sec==-1){
			sec=59;
			min--;
			if(min==-1) {
				min=59;
				hr--;
				if(hr==-1) {
					hr=23;
				}
			}
		}
		
		Time t=new Time(hr,min,sec);
		return t;	
		
	}
}

	


	
	
	
	

;