package chap05.lab11;
/**
 * ------------[Author]--------------
 * 	[Variables]
 * -name:String
 * -email:String
 * -gender:char
 * 	
 * 	[Constructor]
 * +Author(name:String,email:String,gender:char)
 * 
 * 	[Method]
 * +getName():String
 * +getEmail():String
 * +getGender():char
 * 
 * +setEmail(email:String):void
 * 
 * +toString():String
 * 
 * 
 * @author ChengShi
 *
 */
public class Author {
	//--------------<Variables>----------
	private String name;
	private String email;
	private char gender;
	//-------------<Constructor>----------
	
		// Constructor(Default)
	public Author(String name,String email,char gender) {
		this.name=name;
		this.email=email;
		if(gender=='F'||gender=='M'||gender=='f'||gender=='m')this.gender=gender;
		else throw new IllegalArgumentException("Invalid Gender");
		
	}
	
	//-----<PublicMethod>------
	
		//getter
	public String getName() {
		return name;
	}
	public String getEmail() {
		return email;
	}
	public char getGender() {
		return gender;
	}
	
		//setter
	public void setEmail(String input) {
		this.email=input;
	}
	
		//toString
	public String toString() {
		return this.name+"("+this.gender+") at "+this.email;//name(gender) at email;
	}
	
	
}
