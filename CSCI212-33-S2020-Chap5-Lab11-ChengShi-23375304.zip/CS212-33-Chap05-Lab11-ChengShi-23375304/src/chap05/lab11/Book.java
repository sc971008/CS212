package chap05.lab11;
/**
 *--------------[Book]--------------------
 *  [Variables]
 *-name:String
 *-author:Author
 *-price:double
 *-qty:int
 *
 *  [Constructor]
 *+Book(name:String, author:Author, price:double, qty:int)
 *
 *	[Method]
 *+getName():String
 *+getAuthor():Author
 *+getPrice():double
 *+getQty():int
 *
 *+setPrice(price:double):void
 *+setQty(qty:int):void
 *
 *+toString():String
 *
 *
 * @author ChengShi
 *
 */
public class Book {
	//-------------<Variables>---------
	private String name;
	private Author author;
	private double price;
	private int qty;
	//-------------<Constructor>-------
	public Book(String name,Author author,double price,int qty) {
		this.name=name;
		this.author=author;
		this.price=price;
		this.qty=qty;
	}
	//-------------<PublicMethod>------

		//getter
	public String getName() {
		return name;
	}
	public Author getAuthor() {
		return author;
	}
	public double getPrice() {
		return price;
	}
	public int getQty() {
		return qty;
	}
		//setter
	public void setPrice(double input) {
		this.price=input;
	}
	public void setQty(int input) {
		this.qty=input;
	}
		//toString	
		//" 'book-name' by author-name(gender) at email"
	
	public String toString() {
		return"'"+name+"' by "+author.toString();
	}


}	
