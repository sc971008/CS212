package chap05.lab11;

public class TestAuthor {
	public static void main(String agrs[]) {
		
		Author a1=new Author("Cheng Shi","sc971008@gmail.com",'M');
		//getter test
		System.out.println(a1);
		System.out.println("Name:"+a1.getName());
		System.out.println("Email:"+a1.getEmail());
		System.out.println("Gender:"+a1.getGender());
		//setter test
		a1.setEmail("ivan971008@hotmail.com");
		System.out.println(a1);
		System.out.println("Name:"+a1.getName());
		System.out.println("Email:"+a1.getEmail());
		System.out.println("Gender:"+a1.getGender());
		
	}
}
