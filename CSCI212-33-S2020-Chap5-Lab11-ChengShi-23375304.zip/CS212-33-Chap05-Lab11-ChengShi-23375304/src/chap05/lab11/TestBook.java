package chap05.lab11;

public class TestBook {
	public static void main(String args[]) {
		Author sc=new Author("Cheng Shi","sc971008@gmail.com",'M');
		Book b1=new Book("��INTRO TO JAVA��",sc,10.99,5);
		
		//toString test
		System.out.println(b1);
		
		//getter test
		System.out.println("<getter Test>");
		System.out.println("Book Name:"+b1.getName());
		System.out.println("Author:"+b1.getAuthor());
		System.out.println("Price:$"+b1.getPrice());
		System.out.println("Qty:"+b1.getQty());
		
		//setter test
		System.out.println("<settter Test>");
		b1.setPrice(12.99);
		b1.setQty(100);
		System.out.println(b1);
		System.out.println("Book Name:"+b1.getName());
		System.out.println("Author:"+b1.getAuthor());
		System.out.println("Price:$"+b1.getPrice());
		System.out.println("Qty:"+b1.getQty());
		
	}
}
