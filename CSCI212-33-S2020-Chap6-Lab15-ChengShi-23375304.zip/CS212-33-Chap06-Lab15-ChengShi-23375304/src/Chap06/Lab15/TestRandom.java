package Chap06.Lab15;

public class TestRandom {
	public static void main(String[] args) {
		
		//task1
		double[] dData=new double[100];
		for(int i=0;i<dData.length;i++) {
			dData[i]=java.lang.Math.random();
		}
		for(int i=0;i<dData.length;i++) {
			System.out.println(dData[i]);
		}
		
		//task2
		int [] iData=new int[100];
		for(int i=0;i<iData.length;i++) {
			iData[i]=(int)(dData[i]*6)+1;
		}
		for(int i=0;i<iData.length;i++) {
			System.out.println(iData[i]);
		}
		
		//task3
		int [] diceIndex=new int[6];
		for(int i=0;i<diceIndex.length;i++) {
			for(int j=0;j<iData.length;j++) {
				if(iData[j]==i+1) diceIndex[i]++;
			}
		}
		
		//test task3
		for(int i=0;i<diceIndex.length;i++) {
			System.out.println(i+1+":"+diceIndex[i]+"times");
		}
	
	
	
	
	}
}
