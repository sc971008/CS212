package Chap06.Lab15;
/**
 * Test Java.lang.Math Trigonometric Method
 * sin(),cos(),tan(),toRadians();
 * 
 * @author ChengShi
 *
 */
public class TestSine {
	static int dataPoints=33; 
	static double[] sine=new double[dataPoints];
	static double[] radianList=new double[dataPoints];
	
	public static void main(String[] args) {
		
		
		// will have 33 points for x;
		double degreeDifference=360.0/(dataPoints-1);
		//Degree differences between x points;
		System.out.println("Degreee Difference :"+degreeDifference);
		
		
		//degree
		double[] degreeList= new double[dataPoints];
		//get a array for 33 x point value for x in degrees;
		for(int i=0;i<dataPoints;i++) {	
			degreeList[i]=degreeDifference*i;
		}
		System.out.println("[Degree List]");
		for(int i=0;i<dataPoints;i++) {
			System.out.println("x"+(i+1)+":"+degreeList[i]);
		}
	
		//Radian	
		for(int i=0;i<dataPoints;i++) {
			radianList[i]=Math.toRadians(degreeList[i]);
		}
		System.out.println("[Radian List]");
		for(int i=0;i<dataPoints;i++) {
			System.out.println("x"+(i+1)+":"+radianList[i]);
		}
		
		//sin
		for(int i=0;i<dataPoints;i++) {
			sine[i]=Math.sin(radianList[i]);
		}
		for(int i=0;i<dataPoints;i++) {
			System.out.println("x"+(i+1)+":"+sine[i]);
		}
		
		
		
		}
	

}
