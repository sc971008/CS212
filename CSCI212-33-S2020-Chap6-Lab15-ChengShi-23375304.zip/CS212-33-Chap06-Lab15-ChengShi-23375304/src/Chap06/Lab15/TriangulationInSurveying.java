package Chap06.Lab15;

public class TriangulationInSurveying {
	//[Variables]
	double length; 	//distance from A to b
	double alpha;	//A angle for degree;
	double beta;	//B angle for degree;
	double distance;//Distance from boat to shore
	
	
	//[Method]
	public static double findDistance(double length,double alpha,double beta) {	
		if(alpha+beta>180)throw new IllegalArgumentException("Length error: less than 0");
		
		double a=Math.toRadians(alpha);
		double b=Math.toRadians(beta);
		return (length * Math.sin(a) * Math.sin(b)) / Math.sin(a+b);
	}
	
	public static void main(String[] args) {
		System.out.println("alpha:45 beta:45 length:20");
		System.out.println("The distance:"+findDistance(20,45,45));
		//ratio should be be 1:1
		
		System.out.println("alpha:60 beta:60 length:20");
		System.out.println("The distance:"+findDistance(20,60,60));
		//ratio should be be 1:sqrt3
}
	
		
}


