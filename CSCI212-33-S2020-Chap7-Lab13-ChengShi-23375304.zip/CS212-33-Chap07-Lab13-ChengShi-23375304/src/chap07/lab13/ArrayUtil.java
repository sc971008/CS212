package chap07.lab13;

import java.util.Arrays;
/**
 * [Method for arrays]
 * @author ChengShi
 * CS212-33-Chap07
 * CUNY 23375304
 * 
 */
public class ArrayUtil {
	
	//------------Find Smallest Element index
	public static int findSmallestElement(int[] array) {
		
		int[] temp=ArrayUtil.cloneArray(array);
		Arrays.sort(temp);
		int smallestNum=temp[0];
		for(int i=0;i<array.length;i++) {
			if(array[i]==smallestNum)return i;
		}
		return 999999;
	}

	//--------------Find Largest Element index
	public static int findLargestElement(int[] array) {
		
		int[] temp=ArrayUtil.cloneArray(array);
		Arrays.sort(temp);
		int smallestNum=temp[array.length-1];
		for(int i=0;i<array.length;i++) {
			if(array[i]==smallestNum)return i;
		}
		return 999999;
	}
	
	//----------------swap------------------------
	public static int[] swap(int[]a,int i,int j) {
		int[] indexOfi = new int[a.length];
		int[] indexOfj = new int[a.length];;
		int index=0;
		
		//find the place of i & j
		for(int x=0;x<a.length;x++) {
			if(a[x]==i) {//if found an i,store the index;
			indexOfi[index]=x;
			index++;
			}
	
		}
		
		index=0;//reset
		
		for(int x=0;x<a.length;x++) {
			if(a[x]==j) {//if found an j,store the index;
			indexOfj[index]=x;
			index++;
			}
	
		}
	
		
		
		//swap the i & j
		index=0;
		while(indexOfi[index]!=0) {
			a[indexOfi[index]]=j;
			index++;
		}
		
		index=0;
		
		while(indexOfj[index]!=0) {
			a[indexOfj[index]]=i;
			index++;
		}
		if(indexOfi[0]==0)a[0]=j;
		if(indexOfj[0]==0)a[0]=i;
		
		
		return a;
	}	
	
	//----------------swapArrayElements by index------------------------
	public static int[] swapArrayElements(int[]a,int i,int j) {
		int t=a[i];
		a[i]=a[j];
		a[j]=t;
		return a;
	}
	
	//----------------reverseArray-----------
	public static int[] reverseArray(int[]a) {
		int temp[]=new int[a.length];
		int index=0;
		int i=a.length-1;
		while(i!=-1) {
			temp[index]=a[i];
			i--;
			index++;
		}
		
		return temp;
	}
	

	
	//------------------cloneArray
	public static int[] cloneArray(int[] a) {
		int[] b = new int[a.length];
		for(int i=0;i<a.length;i++) {
			b[i]=a[i];
		}
		return b;
	}
	
	//-------------------equals
	public static boolean equals(int[]a,int[]b) {
		if(a.length==b.length) {
			for(int i=0;i<a.length;i++) {
				if(a[i]!=b[i])return false;
			}
			return true;
		}
		else return false;
		
	}
	
	//-----------------sumArray
	public static int sumArray(int[]a) {
		int sum=0;
		for(int i=0;i<a.length;i++) {
			sum+=a[i];
		}
		return sum;
	}
	
	//-----------------averageArray
	public static double averageArray(int[]a) {
		double sum=ArrayUtil.sumArray(a);
		return sum/a.length;
	}
	
	//-----------------validateElementsIn1To9
	public static boolean validateElementsIn1To9(int[]a) {
		for(int i=0;i<a.length;i++) {
			if(a[i]>9||a[i]<1)return false;
		}
		return true;
	}
	
	//-----------------noDupElementArray
	public static boolean noDuplicateElementArray(int[]a) {
		for(int i=0;i<a.length;i++) {
			for(int j=i+1;j<a.length;j++) {
				if(a[i]==a[j])return false;
			}
		}
		return true;
	}
	
	











}
