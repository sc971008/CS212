package chap07.lab13;



public class IntArray30 {
	public static void main(String[]args) {
		int[] a = new int[30];
		
		for(int i=0;i<a.length;i++) {
			a[i]=i+1;
			System.out.print(String.valueOf(a[i])+" ");
			if((i+1)%5==0) {
				System.out.println();
			}
		}
		
		
	}
}