package chap07.lab13;

import java.util.*;

public class TestArrayUtil {
	public static void main(String[]args) {
		
		//test1
		{
		System.out.println("------------test1------------");
		System.out.println("SmalestElement:");
		int a[]= {3,5,9,2,1,7};
		System.out.println(ArrayUtil.findSmallestElement(a));
		int a1[]= {1,2,3,4,5};
		System.out.println(ArrayUtil.findSmallestElement(a1));
		int a11[]= {5,4,3,2,1};
		System.out.println(ArrayUtil.findSmallestElement(a11));
		}
		
		//test2
		{
		System.out.println("------------test2------------");
		System.out.println("LargestElement:");
		int a[]= {3,5,9,2,1,7};
		System.out.println(ArrayUtil.findLargestElement(a));
		int a1[]= {1,2,3,4,5};
		System.out.println(ArrayUtil.findLargestElement(a1));
		int a11[]= {5,4,3,2,1};
		System.out.println(ArrayUtil.findLargestElement(a11));
		}
		
		//test3
		{
		System.out.println("------------test3------------");
		System.out.println("After Swap:");
		int a[]= {1,2,3,4,5};
		System.out.println(Arrays.toString(ArrayUtil.swapArrayElements(a, 0, 4)));
		int a1[]= {5,1,1,5,5};
		System.out.println(Arrays.toString(ArrayUtil.swapArrayElements(a1, 3, 1)));
		
		}
		
		//test4
		{
		System.out.println("------------test4------------");
		System.out.println("After reverse");
		int a[]= {1,2,3,4,5};
		System.out.println(Arrays.toString(ArrayUtil.reverseArray(a)));
		int a1[]= {5,1,1,5,5};
		System.out.println(Arrays.toString(ArrayUtil.reverseArray(a1)));
		
		}
		
		//test7
		{
		System.out.println("------------test7------------");
		System.out.println("Equal or not");
		int a[]= {1,1,1,1,1,1};
		int a1[]= {1,1,1,1,1};
		System.out.println(ArrayUtil.equals(a,a1));
		int b[]= {1,2,1,1,1,};
		int b1[]= {1,2,1,1,1};
		System.out.println(ArrayUtil.equals(b,b1));
		
		
		}
		
		//test8
		{
		System.out.println("------------test8------------");
		System.out.println("The sum:");
		int a[]= {1,2,3,4,5,6,7,8,9,10};
		System.out.println(ArrayUtil.sumArray(a));
		int a1[]= {1,1,1,1,1};
		System.out.println(ArrayUtil.sumArray(a1));
		
		}
	
		
		//test9
		{
		System.out.println("------------test9------------");
		System.out.println("The average:");
		int a[]= {1,2,3,4,5,6,7,8,9,10};
		System.out.println(ArrayUtil.averageArray(a));
		int a1[]= {1,1,1,1,1,1};
		System.out.println(ArrayUtil.averageArray(a1));
		
		}
		
		//test10
		{
		System.out.println("------------test10------------");
		System.out.println("In range[1,9] or not:");
		int a[]= {1,2,3,4,5,6,7,8,9};
		int b[]= {5,3,3,4,3,9,6,7,6};
		int c[]= {5,9,2,4,1,9,8,11,6};
		System.out.println(ArrayUtil.validateElementsIn1To9(a));
		System.out.println(ArrayUtil.validateElementsIn1To9(b));
		System.out.println(ArrayUtil.validateElementsIn1To9(c));
		
		}
		
		//test 12
		{
		System.out.println("------------test12------------");
		System.out.println("Contains dup or not:");
		int a[]= {1,2,3,4,5,6,7,8,9};
		int b[]= {5,3,3,4,3,9,6,7,6};
		int c[]= {5,9,2,4,1,9,8,11,6};
		System.out.println(ArrayUtil.noDuplicateElementArray(a));
		System.out.println(ArrayUtil.noDuplicateElementArray(b));
		System.out.println(ArrayUtil.noDuplicateElementArray(c));

		}
	
	}
}
