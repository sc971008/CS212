package chap07.lab14;
import java.lang.Math;
/**
 * [IntersetTable]
 * Use the equation:[New Money=Initial Money * Rate ^Year]
 * and filling the date in the corresponding place in the array;
 * @author ChengShi
 *
 */
public class InterestTable {
	static Object[][] table= new Object[10][7];
	static double[] rate= {0.05,0.055,0.06,0.065,0.07,0.075};
	
	public static void main(String[]args) {
		//setting up
		for(int i=0;i<table.length;i++) {
			for(int j=1;j<table[i].length;j++) {
				
				table[i][j]=Math.round(1000*Math.pow(1+rate[j-1],i+1));
				//current money is the [New Money=Initial Money * Rate ^Year]
			}
		}	
		
		
		//Printing Rate
		System.out.print("Years"+"\t");
		for(int r=0;r<rate.length;r++) {
			System.out.printf("%.2f",rate[r]*100);
			System.out.print("%"+"\t");
		}
		System.out.println();
		
		
		//Printing Money
		for(int i=0;i<table.length;i++) {
			System.out.print(i+1+"\t");
			for(int j=1;j<table[i].length;j++) {
			System.out.print("$"+table[i][j]+"\t");
			}
			System.out.println();
		}	
		
		
	}
	

	
	
	
}
