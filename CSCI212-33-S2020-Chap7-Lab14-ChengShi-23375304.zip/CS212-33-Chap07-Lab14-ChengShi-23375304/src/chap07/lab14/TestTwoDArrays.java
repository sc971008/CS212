package chap07.lab14;

import java.util.Arrays;

public class TestTwoDArrays {
	public static void main(String[]args) {
		
		//1.SquareArrayWithRowsSequenceInIt
		{
		System.out.println("---------------Test1------------");	
		int[][] a=TwoDArrays.getSquareArrayWithRowSequenceInit(4);
		for(int[] x:a)
		System.out.println(Arrays.toString(x));
		}
	
	
		//2.SquareArrayWithRowsSequenceInIt (Reversed)
		{
		System.out.println("---------------Test2------------");	
		int[][] a=TwoDArrays.getSquareArrayWithRowSequenceInitReversed(4);
		for(int[] x:a)
		System.out.println(Arrays.toString(x));
		}
		
		//3.TriangleArray
		{
		System.out.println("---------------Test3------------");	
		int[][] a=TwoDArrays.getTriangleArrayWithRowSequenceInit(5);
		for(int[] x:a)
		System.out.println(Arrays.toString(x));
		}
	
	
		//clone2DArray
		{
		System.out.println("---------------Test5------------");
		
		int[][] a=TwoDArrays.getSquareArrayWithRowSequenceInit(5);
		for(int[] x:a)
		System.out.println(Arrays.toString(x));
		
		System.out.println("---------------After Cloned------------");
		
		int[][] b=TwoDArrays.clone2DArray(a);
		for(int[] x:b)
			System.out.println(Arrays.toString(x));
		
		
		System.out.println("---------------After Transpose------------");
		TwoDArrays.transpose(a);
		for(int[] x:a)
			System.out.println(Arrays.toString(x));
		}
		
	}
}
