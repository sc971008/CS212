package chap07.lab14;


/**
 * 
 * @author ChengShi
 *
 * setTimebook():
 * Set the data for the total[] & timeBook[][]
 *	
 */

public class TimeBook {
	static Object[][] timeBook= new Object[6][5];
	static int[] total=new int[3];

	public static void setTimeBook() {
		
		timeBook[0]=new Object[]{"Employee "	,1,2,3	,"Totals"};
		timeBook[1]=new Object[]{"Monday   "	,8,0,9	,17};
		timeBook[2]=new Object[]{"Wednesday"	,8,0,9	,17};
		timeBook[3]=new Object[]{"Thursday "	,8,8,8	,24};
		timeBook[4]=new Object[]{"Friday   "	,8,8,4	,20};
		timeBook[5]=new Object[]{"Friday   "	,8,8,8	,24};
		
		total= new int[]{40,24,38};
	}
	
	
	
	public static void printTimeBook() {
		
		//print the week table
		for(int i=0;i<timeBook.length;i++) {
			for(int j=0;j<timeBook[i].length;j++) {
				System.out.print(timeBook[i][j]+"\t");
			}
			System.out.println();
		}
		
		//print the total of week for every employee;
		System.out.print("Total=     \t");
		for(int i=0;i<total.length;i++) {
			System.out.print(total[i]+"\t");
		}
	
	}
	
	
	public static void main(String[] args) {
		setTimeBook();
		printTimeBook();
	}
}
