package chap07.lab14;
/**
 * QC CSCI 212-33 S2020 Lab 14
 * @author ChengShi
 *
 */
public class TwoDArrays {
	//Constructor
	private TwoDArrays() {
		
	}

	//1.SquareArrayWithRowsSequenceInIt
	public static int[][] getSquareArrayWithRowSequenceInit(int size){
		int[][] square=new int[size][size];
		int count=1;
		for(int r=0;r<square.length;r++) {
			for(int c=0;c<square[r].length;c++) {
				square[r][c]=count;
				count++;
			}
		}
		return square;
		}
	
	//2.SquareArrayWithRowsSequenceInIt Reversed
		public static int[][] getSquareArrayWithRowSequenceInitReversed(int size){
			int[][] square=new int[size][size];
			int count=1;
			for(int r=square.length-1;r>=0;r--) {
				for(int c=square[r].length-1;c>=0;c--) {
					square[r][c]=count;
					count++;
				}
			}
			return square;
			}
	//3.TriangleArray
		public static int[][] getTriangleArrayWithRowSequenceInit(int size){
			int c=0;
			int r=0;
			int count=1;
			
			int[][] triangle=new int[size][];
		
			for(r=0;r<size;r++) {
				triangle[r]=new int[c+1];//set the size for the row;
				for(c=0;c<=r;c++) {		
					triangle[r][c]=count;
					count++;
				}
				count=1;	
			}
			return triangle;
		}

	//4.transpose
		public static void transpose(int[][] x) {
			//clone the array
			int[][]cloned=TwoDArrays.clone2DArray(x);
			//
			for(int r=0;r<x.length;r++) {
				for(int c=0;c<x[r].length;c++) {
					x[r][c]=cloned[c][r];
				}
			}
		}
		
	//---clone2DArray
	public static int[][] clone2DArray(int[][] a) {
		int[][] b = new int[a.length][];
		int r=0;
		int c=0;
		
		for(r=0;r<a.length;r++) {
			b[r]=new int[a[r].length];//set the size for the row
			for(c=0;c<a[r].length;c++) {
			b[r][c]=a[r][c];
			}
		}
		return b;
	}







}
