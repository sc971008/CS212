package midterm2;

public class Prog1 {
	//------------[Task1]----------
	//1.1
	public static int search(int[] a, int key) {
		for(int i=0;i<a.length;i++) {
			if(a[i]==key)return i;
		
		}
		return -1;
	}
	
	//1.2
	public static int[] search(int[][] a,int key) {
		int[] index=new int[2];
		for(int r=0;r<a.length;r++) {
			for(int c=0;c<a[r].length;c++) {
				if(a[r][c]==key) {
					index[0]=r;
					index[1]=c;
				}
				
		
			}
		}
		return index;
	}
	
	//1.3
	
	public static int[] selectionSort(int[] a) {
		int length=a.length;
		
			for(int i=0;i<length-1;i++) {
				int min_idx=i;
				for(int hook=i+1;hook<length;hook++) {
					if(a[hook]<a[min_idx]) {
						min_idx=hook;
					}
				}
				swapArrayElements(a,min_idx,i);
			}
			
			return a;
			
	}
	
	//swap
	public static int[] swapArrayElements(int[]a,int i,int j) {
		int t=a[i];
		a[i]=a[j];
		a[j]=t;
		return a;
	}
	
	//---clone2DArray
		public static int[][] clone2DArray(int[][] a) {
			int[][] b = new int[a.length][];
			int r=0;
			int c=0;
			
			for(r=0;r<a.length;r++) {
				b[r]=new int[a[r].length];//set the size for the row
				for(c=0;c<a[r].length;c++) {
				b[r][c]=a[r][c];
				}
			}
			return b;
		}
	
	//1.4
	public static void verticalFlip(int[][]a){
		int row=a.length;
		int[][] temp=clone2DArray(a);
		for(int r=0;r<a.length;r++) {
			row--;
			for(int c=0;c<a[r].length;c++) {
			a[row][c]=temp[r][c];
				
			}
			
		}
	
	}
	
	//1.5
	//"abadbfg"
	public static String removeDuplicates(String text) {
		text=text.toUpperCase();
		text=text.replace(" ", "");
		int length=text.length();
		for(int i=0;i<length;i++) {
			for(int j=i;j<length-1;j++) {
				if(text.substring(i,i+1).contentEquals(text.substring(j, j+1))){
					if(i==0)text=text.substring(i+1);
					else {
						text=text.substring(0,j)+text.substring(j);
					}
				}
			}
		}
		return text;
	}
	
	//1.6
	public static boolean uniqueNumbersFrom1to9(int[] data) {
		for(int i=0;i<data.length-1;i++) {
			if(data[i]>9||data[i]<1) return false;
			for(int hook=0;hook<data.length-1;hook++) {
				if(hook==i)hook++;
				if(data[hook]==data[i])return false;
			}
			
		}
		return true;
	}
	
	//1.7
	public static void fibonacciNumber(long[] a) {
		for(int i=2;i<a.length;i++) {
			a[i]=a[i-1]+a[i-2];
		}
	
	}
	
	//1.8
	
	
	
	
}
