package midterm2;
import java.util.*;
public class Prog1Test {
	public static void main(String[] args) {
	//----test1.1
	{
	System.out.println("--------------Test1.1");
	int a[]= {1,3,4,5,6};
	System.out.println(Prog1.search(a, 3));
	}
	
	//----test1.2
	{
	System.out.println("--------------Test1.2");
	int a[][]= {{1,2,3},
				{4,5,6},
				{7,8,9}};
	System.out.println(Arrays.toString(Prog1.search(a, 4)));
	System.out.println(Arrays.toString(Prog1.search(a, 9)));
	System.out.println(Arrays.toString(Prog1.search(a, 10)));
	}
		
	//-----test1.3
	{
	System.out.println("--------------Test1.3");
	int a[]= {5,3,6,7,8};
	System.out.println(Arrays.toString(Prog1.selectionSort(a)));
	
	}
	//------test1.4
	{
	System.out.println("--------------Test1.4");
	int a[][]= {{1,2,3},
				{4,5,6},
				{7,8,9}};
	Prog1.verticalFlip(a);
	System.out.println(Arrays.deepToString(a));
	}
	//------test1.5
//	{
//	System.out.println("-------------------test1.5");
//	String a="The rain in Spain stays mainly in the plain";
//	System.out.println(Prog1.removeDuplicates(a));
//	}
	//-------test1.6
	{
	System.out.println("-------------------test1.6");
	int a[]= {1,2,3,4,5};
	System.out.println(Prog1.uniqueNumbersFrom1to9(a));
	int b[]= {1,2,1,4,5};
	System.out.println(Prog1.uniqueNumbersFrom1to9(b));
	}
	//-------test1.7
	{
	System.out.println("-------------------test1.6");
	long a[]= {1,2,3,4,5,6,7,8};
	Prog1.fibonacciNumber(a);
	for(int i=0;i<a.length;i++) {
		System.out.print(a[i]+" ");
	}
	}
	
	
	
	
		
		
		
		
		
		
	}
}
