package midterm2;
import java.util.*;

public class Prog2 {
	public static void main(String[]args) {
		Scanner Userinput=new Scanner(System.in);
		boolean ans=false;
		int pointTest = 0;
		double Pi=0;
		double r=0;
		double n=0;
		
		while(ans!=true) {
			System.out.println("Enter the amount of test points:");
			pointTest=Userinput.nextInt();
			if(pointTest<0) {
			System.out.println("Input Error:Negative");
			}
			break;
		}
		
		Prog2 test=new Prog2();
		
		for(int i=0;i<pointTest;i++) {
			
			double []Point=getPoints();
			if(insideUnitCircle(Point)) {
				r++;
				
			}
			else n++;
		}
		Pi=4.0*(r/n);
		System.out.println("Number of points tested:"+pointTest+"Pi is Aprx="+Pi);

	}
	//get Value
	public static double getValue() {
		double dice=Math.random();
		if(dice>0.5) {
		return Math.random();
		}
		else return Math.random()*-1;
	}
	
	//getPoint
	public static double[] getPoints() {
		double[] point= new double[2];
		point[0]=getValue();
		point[1]=getValue();
		return point;
	}

	//insideUniteCirce
	static boolean insideUnitCircle(double[] point) {
		double rOfPoint=Math.sqrt(Math.abs(point[0])+Math.abs(point[1]));
		//get the radius of the points from the center
		
		if(rOfPoint<1)return true;
		else return false;
	}
	
	
}


