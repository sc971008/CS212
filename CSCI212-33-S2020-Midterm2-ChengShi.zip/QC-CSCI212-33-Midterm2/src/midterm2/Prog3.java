package midterm2;

public class Prog3
{
public static void main(String[] args) {
Student stu = new Student("John","Smith",12345678);

stu.addScore(89, 100);
stu.addScore(7, 10);
stu.addScore(16, 20);
stu.addScore(72, 100);
stu.addScore(9, 10);
stu.addScore(5, 10);
stu.addScore(19, 20);
stu.addScore(171, 200);
stu.printStudentReport();
}
}
