package midterm2;

public class Student {
	//--------variables
	private String firstName;
	private String lastName;
	private int studentID;
	private int[][] score=new int[2][100];
	private int scoreCount;
	

	
	//---------Constructor
	public Student(String firstName, String lastName,int studentID) {
		this.firstName=firstName;
		this.lastName=lastName;
		this.studentID=studentID;
		//put in all with -1 to check
		for(int i=0;i<score.length-1;i++) {
			for(int j=0;j<score[i].length;j++) {
				this.score[i][j]=-1;
			}
		}
	}
	
	//--------Method
	
	//addScore
	public void addScore(int scores,int fullGrade) {
		score[0][scoreCount]=scores;
		score[1][scoreCount++]=fullGrade;
		
	}
//		for(int i=0;i<this.score[1].length;i++) {
//			while(this.score[0][i]!=-1) {
//				i++;
//			}
//			this.score[0][i]=score;
//			this.score[1][i]=fullGrade;
//			this.scoreCount++;
//			}
//			
//		}
	
	
	
	
	//printScores
	private void printScores() {
		System.out.println("Score\t"+"Vaule\t");
		for(int i=0;i<this.score[1].length;i++) {
			if(score[0][i]==-1)break;
			System.out.println(score[0][i]+"\t"+score[1][i]);
		}
	}
	
	//calculatePercentAvg
	private double calculatePercentAvgerage() {
		double sumOfScore=0;
		double sumofAssign=0;
		
		for(int i=0;i<scoreCount;i++) {
			sumOfScore+=score[0][i];
			sumofAssign+=score[1][i];
		}
		double avg=(sumOfScore/sumofAssign)*100;
		return avg;
		
	}
	//LetterGrade
	private String calculateLetterGrade() {
		double avg=calculatePercentAvgerage();
		if(avg>=90)return "A";
		else if(avg<90 && avg>=80)return "B";
		else if(avg<80 && avg>=70)return "C";
		else if(avg<70 && avg>=60)return "D";
		else return "F";
	}
	//Student Report
		
	public void printStudentReport() {
		System.out.println("Name: \t"+this.lastName+","+this.firstName);	
		System.out.println("Student ID: "+this.studentID);
		printScores();
		System.out.println(calculatePercentAvgerage());
		System.out.println(calculateLetterGrade());
	}
	
	//test private method
	public static void main(String[]args) {
		Student bob=new Student("bob","shi",23375304);
		bob.addScore(10, 100);
		bob.addScore(20, 100);
		bob.addScore(30, 100);
		bob.addScore(50, 100);
		bob.printScores();
		System.out.println(bob.calculatePercentAvgerage());
		System.out.println(bob.calculateLetterGrade());
		
		bob.printStudentReport();
		
	}
}
