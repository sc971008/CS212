package finalexam.ques3;

public class Person {
	//-----<variables>----
	private String name;
	private int age;
	//------<Constructor>---
	public Person(String name,int age)  {
			this.name=name;
			this.age=age;
	}
	//------<Method>----
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public boolean equals(Person other) {
		if(other instanceof Person) {
			if(this.name==other.name&& this.age==other.age) {
				return true;
			}
			else return false;
		}
		return false;
	}
	//------<toString>-----
	@Override
	public String toString() {
		return "Person[Name="+name+",Age=+"+age+"]";
	}
}
