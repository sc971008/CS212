package finalexam.ques3;

public class PersonDemo {
	public static void main(String[]args) {
		Person s=new Person("Dave",11);
		Person v=new Person("Dave",11);
		System.out.println(s.equals(v));
	}
}
