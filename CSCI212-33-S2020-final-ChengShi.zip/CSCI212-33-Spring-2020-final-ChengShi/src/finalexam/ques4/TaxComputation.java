package finalexam.ques4;

public class TaxComputation {
	//----<Variables>------
	private double basicRate=4.0/100;
	private double luxuryRate=10.0/100;
	//----<Constructor>----
	public TaxComputation (){};
	public TaxComputation(double basicRate,double luxuryRate) throws Exception {
		this.basicRate=basicRate;
		this.luxuryRate=luxuryRate;
	}
	//-----<Method>----
	public static double roundToNearestPenny(double price) {
		return Math.round(price* 100.0) / 100.0;
	}
	
	public double computeCostBasic(double price) {
		try {
			if(price<0) throw new IllegalArgumentException();
			}
			catch(IllegalArgumentException e) {
				System.out.println("Price can't be negative.");
			}
			
		double basicTax=price*basicRate;
		price=price+basicTax;
		return roundToNearestPenny(price);
	}
	public double computeCostLuxury(double price) {
		try {
			if(price<0) throw new Exception();
			}
			catch(Exception e) {
				System.out.println("Price can't be negative.");
			}
		
		double luxuryTax=price*luxuryRate;
		price=price+luxuryTax;
		return roundToNearestPenny(price);
		
	}
	//----test----
	public static void main(String[] args) {
		double a=111.225;
		System.out.println(roundToNearestPenny(a));
	}

}
