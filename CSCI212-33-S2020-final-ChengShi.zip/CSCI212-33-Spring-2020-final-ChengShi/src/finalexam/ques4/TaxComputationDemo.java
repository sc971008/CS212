package finalexam.ques4;
public class TaxComputationDemo {

	public static void main(String[] args) {
	    TaxComputation tc = new TaxComputation();
	    
	    double basicPrice = 100;
	    double result = tc.computeCostBasic(basicPrice);
	    System.out.println(
	    		"tc.computeCostBasic(" + 
	             basicPrice + 
	             " ) returns " + 
	             result);	    
	    
	    basicPrice = -10;
	    result = tc.computeCostBasic(basicPrice);
	    System.out.println(
	    		"tc.computeCostBasic(" + 
	             basicPrice + 
	             " ) returns " + 
	             result);	    
	    
	    double luxuryPrice = 10000;
        result = tc.computeCostLuxury(luxuryPrice);
	    System.out.println(
	    		"tc.computeCostLuxury(" + 
	    				luxuryPrice + 
	             " ) returns " + 
	             result);
	}
}