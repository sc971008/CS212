package finalexam.ques5.abstract_class;

public class AbstractClassDemo {

  public static void main(String[] args) {
       System.out.println("Demo polymorphism via abstract class method override");
	 AbstractShape[] abstractShapes = { 
				new Circle(1),
				new Rectangle(2, 3)
	   	             };
		
	 for ( AbstractShape s: abstractShapes) {
			System.out.println("class name " + s.getClass().getSimpleName());
			System.out.println("    getPerimeter() returns " + s.getPerimeter());
	 }
   }
}	
