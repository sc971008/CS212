package finalexam.ques5.abstract_class;

public abstract class AbstractShape {
	abstract double getPerimeter() ;
}
