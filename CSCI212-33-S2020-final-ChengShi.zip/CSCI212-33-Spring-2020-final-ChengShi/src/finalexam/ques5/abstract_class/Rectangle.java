package finalexam.ques5.abstract_class;


public class Rectangle extends AbstractShape{
	//----<Variables>---
	double length=0.0;
	double width=0.0;
	//----<Constructor>---
	 public Rectangle(double length,double width){
	        this.length=length;
	        this.width=width;
	    }

	//-----<Method>----
	public double getPerimeter() {
        return 2*(length+width);
    }
}