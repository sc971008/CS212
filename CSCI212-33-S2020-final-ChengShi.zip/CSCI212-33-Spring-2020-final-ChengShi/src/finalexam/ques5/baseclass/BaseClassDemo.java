package finalexam.ques5.baseclass;


public class BaseClassDemo {

	public static void main(String[] args) {
		System.out.println("Demo polymorphism via baseclass" + 
	                       " inheritance method override");
		Shape [] shapes = {  new Circle(1),  
				             new Rectangle(2, 3)
				          };
		
		for ( Shape s:  shapes)
		{ 
		    System.out.println("classname = " + 
		                       s.getClass().getName()
		                      );
		    System.out.println("    getPerimeter() returns " + 
		                       s.getPerimeter()
		                      );
		}
	}
}

