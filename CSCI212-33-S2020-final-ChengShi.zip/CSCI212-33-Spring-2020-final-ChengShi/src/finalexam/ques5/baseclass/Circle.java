package finalexam.ques5.baseclass;

public class Circle extends Shape {
	
	//<Variables>
		public double radius=1.0;
	//<Constructor>
	public Circle(double radius) {
		this.radius=radius;
	}
	//<Method>
	public double getPerimeter() {
		return 2*Math.PI*radius;
	}
}
