package finalexam.ques5.baseclass;

public class Rectangle extends Shape{
	//----<Variables>---
	double length=0.0;
	double width=0.0;
	//----<Constructor>---
	 public Rectangle(double length,double width){
	        this.length=length;
	        this.width=width;
	    }

	//-----<Method>----
	public double getPerimeter() {
        return 2*(length+width);
    }
}
