package finalexam.ques5.baseclass;

public class Shape {
	public double getPerimeter() {
		return 0.0;
	}
}
