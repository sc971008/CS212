package finalexam.ques5.comm_interface;

public class Circle implements Measurable{


	//<Variables>
			public double radius=1.0;
	//<Constructor>
	public Circle(double radius) {
		this.radius=radius;
	}
	//<Method>

	public double getPerimeter() {
		return 2*Math.PI*radius;
	}


}
