package finalexam.ques5.comm_interface;

public class CommInterfaceDemo {

	public static void main(String[] args) {
		System.out.println("Demo polymorphism via common" + 
                " interface method override");
		Measurable[] measures = { new Circle(1), new Rectangle(2, 3) };
		
		for (Measurable m : measures) {
			System.out.println( "class name = " + 
		                        m.getClass().getSimpleName() +
             					", interface name = " + 
		                        m.getClass().getInterfaces()[0].getSimpleName());
			
			System.out.println("    getPerimeter() returns " + m.getPerimeter());
		}
	}
}
