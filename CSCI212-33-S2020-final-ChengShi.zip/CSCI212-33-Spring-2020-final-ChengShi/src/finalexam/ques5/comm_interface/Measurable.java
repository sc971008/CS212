package finalexam.ques5.comm_interface;

public interface Measurable {
	 double getPerimeter();
}
