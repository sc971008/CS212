package finalexam.ques5.comm_interface;

public class Rectangle implements Measurable {
	//----<Variables>---
	double length=0.0;
	double width=0.0;
	//----<Constructor>---
	 public Rectangle(double length,double width){
	        this.length=length;
	        this.width=width;
	    }

	//-----<Method>----
	public double getPerimeter() {
		  return 2*(length+width);
	}
    
}
